"""
Documents app for file uploads and management.
"""
