"""
Temporal workflow orchestration for agent execution.
"""
