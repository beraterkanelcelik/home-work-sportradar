"""
LangGraph Functional API implementation.
"""
from app.agents.functional.workflow import ai_agent_workflow

__all__ = ['ai_agent_workflow']
