"""
Document chunking strategy.
"""
# TODO: Implement document splitting
# - Use LangChain text splitters
# - Support different chunking strategies
# - Preserve metadata


def split_document(text: str, chunk_size: int = 1000, chunk_overlap: int = 200):
    """
    Split document into chunks.
    """
    # TODO: Implement document splitting
    pass
