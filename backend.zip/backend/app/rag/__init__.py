"""
RAG (Retrieval Augmented Generation) package.
"""
