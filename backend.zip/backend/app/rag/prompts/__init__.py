"""
RAG prompt formatting utilities.
"""
