"""
Account app for user management and authentication.
"""
