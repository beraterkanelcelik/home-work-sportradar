"""
Account API endpoints.
"""
