"""
Database package.
"""
default_app_config = 'app.db.apps.DbConfig'