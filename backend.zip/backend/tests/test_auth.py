"""
Authentication tests.
"""
from django.test import TestCase

# TODO: Write authentication tests
# - Test user signup
# - Test user login
# - Test token refresh
# - Test logout
