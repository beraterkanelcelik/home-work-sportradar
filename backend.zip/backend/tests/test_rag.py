"""
RAG tests.
"""
from django.test import TestCase

# TODO: Write RAG tests
# - Test document ingestion
# - Test vector search
# - Test multi-tenant isolation
